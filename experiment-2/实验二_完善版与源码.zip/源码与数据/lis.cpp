#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
    int n;
    cout << "请输入序列的长度 n: ";
    if (!(cin >> n)) return 0;
    if (n < 0) { cout << "输入规模无效"; return 0; }
    vector<int> a(n);
    cout << "请输入 " << n << " 个整数:" << endl;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    vector<int> dp(n, 1);
    vector<int> pre(n, -1);
    int ans = 0;
    int endPos = -1;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (a[j] < a[i] && dp[j] + 1 > dp[i]) {
                dp[i] = dp[j] + 1;
                pre[i] = j;
            }
        }
        if (dp[i] > ans) {
            ans = dp[i];
            endPos = i;
        }
    }
    vector<int> seq;
    for (int i = endPos; i != -1; i = pre[i]) {
        seq.push_back(a[i]);
    }
    reverse(seq.begin(), seq.end());
    cout << "LIS长度 = " << ans << endl;
    cout << "一个LIS: ";
    for (int i = 0; i < (int)seq.size(); i++) {
        cout << seq[i] << " ";
    }
    cout << endl;
    return 0;
}