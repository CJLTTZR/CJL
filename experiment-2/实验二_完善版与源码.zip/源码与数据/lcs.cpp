#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
int main() {
    string X, Y;
    cout << "请输入第一个字符串 X: ";
    if (!getline(cin, X)) return 0;
    cout << "请输入第二个字符串 Y: ";
    if (!getline(cin, Y)) return 0;
    int m = X.size();
    int n = Y.size();
    vector<vector<int> > dp(m + 1, vector<int>(n + 1, 0));
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (X[i - 1] == Y[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }
    string s;
    int i = m;
    int j = n;
    while (i > 0 && j > 0) {
        if (X[i - 1] == Y[j - 1]) {
            s.push_back(X[i - 1]);
            i--;
            j--;
        } else if (dp[i - 1][j] >= dp[i][j - 1]) {
            i--;
        } else {
            j--;
        }
    }
    reverse(s.begin(), s.end());
    cout << "LCS长度 = " << dp[m][n] << endl;
    cout << "一个LCS = " << s << endl;
    return 0;
}