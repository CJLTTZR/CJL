#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long operations = 0;
int main() {
    struct Counter { long long &v; ~Counter(){ cerr << "OPS=" << v << endl; } } counter{operations};
    int N, E;
    cout << "请输入多段图的顶点数 N (编号0到N-1，0为源点，N-1为终点) 和边数 E: ";
    if (!(cin >> N >> E)) return 0;
    if (N <= 0 || E < 0) { cout << "输入规模无效"; return 0; }
    vector<vector<pair<int, int> > > adj(N);
    cout << "请依次输入 " << E << " 条边 (起点 终点 权重):" << endl;
    for (int i = 0; i < E; i++) {
        int u, v, w;
        if (!(cin >> u >> v >> w) || u < 0 || v >= N || u >= v) {
            cout << "边须满足0 <= u < v < N，顶点按阶段拓扑编号"; return 0;
        }
        adj[u].push_back(make_pair(v, w));
    }
    const int INF = 1000000000;
    vector<int> d(N, INF);
    vector<int> pre(N, -1);
    d[0] = 0;
    for (int u = 0; u < N; u++) {
        if (d[u] == INF) continue;
        for (int e = 0; e < (int)adj[u].size(); e++) {
            ++operations;
            int v = adj[u][e].first;
            int w = adj[u][e].second;
            if (d[u] + w < d[v]) {
                d[v] = d[u] + w;
                pre[v] = u;
            }
        }
    }
    cout << "多段图最短路径长度 = " << d[N - 1] << endl;
    if (d[N - 1] == INF) {
        cout << "无法到达终点！" << endl;
        return 0;
    }
    vector<int> path;
    for (int x = N - 1; x != -1; x = pre[x]) {
        path.push_back(x);
    }
    reverse(path.begin(), path.end());
    cout << "路径: ";
    for (int i = 0; i < (int)path.size(); i++) {
        cout << path[i];
        if (i + 1 != (int)path.size()) cout << " -> ";
    }
    cout << endl;
    return 0;
}