#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long operations = 0;
int main() {
    struct Counter { long long &v; ~Counter(){ cerr << "OPS=" << v << endl; } } counter{operations};
    int n, W;
    cout << "请输入物品数量 n 和背包容量 W: ";
    if (!(cin >> n >> W)) return 0;
    if (n < 0 || W < 0) { cout << "输入规模无效"; return 0; }
    vector<int> w(n), v(n);
    cout << "请依次输入 " << n << " 个物品的重量和价值 (重量 价值):" << endl;
    for (int i = 0; i < n; i++) {
        if (!(cin >> w[i] >> v[i]) || w[i] <= 0) { cout << "重量须为正整数"; return 0; }
    }
    vector<vector<int> > dp(n + 1, vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= W; j++) {
            ++operations;
            if (j < w[i - 1]) {
                dp[i][j] = dp[i - 1][j];
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - w[i - 1]] + v[i - 1]);
            }
        }
    }
    vector<int> chosen;
    int j = W;
    for (int i = n; i >= 1; i--) {
        if (dp[i][j] != dp[i - 1][j]) {
            chosen.push_back(i);   
            j -= w[i - 1];
        }
    }
    reverse(chosen.begin(), chosen.end());
    cout << "0-1背包最大价值 = " << dp[n][W] << endl;
    cout << "选择物品编号(从1开始): ";
    for (int i = 0; i < (int)chosen.size(); i++) {
        cout << chosen[i] << " ";
    }
    cout << endl;
    return 0;
}