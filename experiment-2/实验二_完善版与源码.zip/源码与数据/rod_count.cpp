#include <iostream>
#include <vector>
#include <limits>
using namespace std;
long long operations = 0;
int main() {
    struct Counter { long long &v; ~Counter(){ cerr << "OPS=" << v << endl; } } counter{operations};
    int n;
    cout << "请输入钢条总长度 n: ";
    if (!(cin >> n)) return 0;
    if (n < 0) { cout << "输入规模无效"; return 0; }
    vector<int> p(n + 1, 0);
    cout << "请依次输入长度为 1 到 " << n << " 的钢条价格:" << endl;
    for (int i = 1; i <= n; i++) {
        cin >> p[i];
    }
    vector<int> dp(n + 1, 0);
    vector<int> cut(n + 1, 0);
    for (int j = 1; j <= n; j++) {
        int best = numeric_limits<int>::lowest();
        int bestCut = 0;
        for (int i = 1; i <= j; i++) {
            ++operations;
            if (p[i] + dp[j - i] > best) {
                best = p[i] + dp[j - i];
                bestCut = i;
            }
        }
        dp[j] = best;
        cut[j] = bestCut;
    }
    cout << "钢条最大收益 = " << dp[n] << endl;
    cout << "切割方案: ";
    int x = n;
    while (x > 0) {
        cout << cut[x] << " ";
        x -= cut[x];
    }
    cout << endl;
    return 0;
}