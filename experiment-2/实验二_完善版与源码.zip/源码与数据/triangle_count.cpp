#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long operations = 0;
int main() {
    struct Counter { long long &v; ~Counter(){ cerr << "OPS=" << v << endl; } } counter{operations};
    int n;
    cout << "请输入数塔的层数 n: ";
    if (!(cin >> n)) return 0;
    if (n <= 0) { cout << "数塔层数须为正整数"; return 0; }
    vector<vector<int> > a(n, vector<int>(n, 0));
    cout << "请依次输入数塔数据 (第 i 行有 i 个数字):" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            cin >> a[i][j];
        }
    }
    vector<vector<int> > dp = a;
    vector<vector<int> > choice(n, vector<int>(n, -1));
    for (int i = n - 2; i >= 0; i--) {
        for (int j = 0; j <= i; j++) {
            ++operations;
            if (dp[i + 1][j] >= dp[i + 1][j + 1]) {
                dp[i][j] = a[i][j] + dp[i + 1][j];
                choice[i][j] = 0;
            } else {
                dp[i][j] = a[i][j] + dp[i + 1][j + 1];
                choice[i][j] = 1;
            }
        }
    }
    cout << "数塔最大路径和 = " << dp[0][0] << endl;
    cout << "路径: ";
    int j = 0;
    for (int i = 0; i < n; i++) {
        cout << a[i][j];
        if (i != n - 1) cout << " -> ";
        if (i < n - 1 && choice[i][j] == 1) {
            j++;
        }
    }
    cout << endl;
    return 0;
}